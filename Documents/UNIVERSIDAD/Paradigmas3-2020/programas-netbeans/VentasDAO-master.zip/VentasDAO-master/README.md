# VentasDAO

Proyecto que contiene el Alta de Categoria y Clientes con JDBC


### Installing 🔩
Ejecutar scripts de la en la base de datos

```
script01.sql
```

```
script02.sql
```
contienen los scripts de la base de datos

### Settings ⌨️

Configurar los atributos de Conexion de la Clase  ConnectionFactory y ademas agregar el jar de postgres a la libreria
